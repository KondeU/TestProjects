# CConfig

The project provides a CConfig class that can operate (read and write) a suitable configuration file (see the sample files: Config_Origin.cfg), the contents of the configuration file will be loaded into memory at once to Accelerate searching and matching.